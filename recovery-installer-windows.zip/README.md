# Recovery Installer for Windows

Disclaimer : I'm not responsible for any damage inflicted to the device by the usage of this software. Please undertand the risks before using it.

An automated TWRP installer for Windows Users

A simple attempt to make the TWRP installation process easier for unlocked devices. 

Supported Devices : Redmi 4x(Santoni), Redmi Note 4X(Mido), Redmi Note 8(Ginkgo), Redmi Note 8T(Willow)

Contains Minimal ADB & Fastboot and Google USB Drivers.

Download Link : https://github.com/uncannyjish/recovery-installer-windows/releases

Please don't tamper the directory structure and follow the instructions carefully.

Feedbacks are appreciated.

Telegram - https://t.me/talktouncannyjish
